                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            #include "mbed.h"


// # Product name: L298N motor driver module DF-MD v1.3
// # Product SKU : DRI0002
// # Version     : 1.0

// # Description:
// # The sketch for using the motor driver L298N
// # Run with the PWM mode

// # Connection:
// #        M1 pin  -> Digital pin 4
// #        E1 pin  -> Digital pin 5
// #        M2 pin  -> Digital pin 7
// #        E2 pin  -> Digital pin 6
// #        Motor Power Supply -> Centor blue screw connector(5.08mm 3p connector)
// #        Motor A  ->  Screw terminal close to E1 driver pin
// #        Motor B  ->  Screw terminal close to E2 driver pin
// #
// # Note: You should connect the GND pin from the DF-MD v1.3 to your MCU controller. They should share the GND pins.
// #

#define HIGH 1
#define LOW 0


    // Initialisation des pins 
DigitalOut M1(D6);
PwmOut E1(D7);
DigitalOut M2(D4);
PwmOut E2(D5);
I2C i2c(I2C_SDA, I2C_SCL);
AnalogIn rota(A3);


const int adrLCD = 0x3E << 1;
const int adrLED = 0x62 << 1;

void write_cmd(char c);
void write_data(char c);
void write_data_2(char c);
void init_LCD();
void print_LCD_char(char c);
void print_LCD_String(char *s);
void write_ctrl_LED(char c1, char c2);
void color(char rouge, char vert, char bleu);

int main(){
    int n;
    float f;
    char str[2];
    init_LCD();
    color(0x00, 0x00, 0xFF); 
    print_LCD_String("Potentiometre = ");
    write_cmd(0xC0);


    /*for(int i = 0; i < 1000; i++){//Changement de couleur avec un compteur
        n = sprintf(str,"%d", i);
        write_cmd(0xC0); sauter une ligne
        print_LCD_String(str);
        if(i % 2 == 0) color(0x00, 0xF0, 0x00);
        else color(0x00, 0x00, 0xF0);
        wait(1);
    }*/

    while(1)
    {
        int value;
        float vitesse;
        M1=LOW; 
        M2=HIGH;
        E1.write(HIGH);
        E2.write(HIGH);
        wait(1);
        M1=HIGH; 
        M2=HIGH;
        wait(1);
        M1=HIGH; 
        M2=LOW;
        wait(1);
        }

}



void write_cmd(char c){
   char commande[2] = {0x80, c};
   i2c.write(adrLCD, commande, 2);
}

void write_data(char c){
    char commande[2] = {0x40, c};
    i2c.write(adrLCD, commande, 2);
    wait_us(43);
}

void init_LCD(){
    //Séquence d'initialisation
    wait_ms(31);
    write_cmd(0x3C); //Mode 2 lignes, affichage
    wait_us(40);
    write_cmd(0x0F); //Affichage, curseur et clignotement du curseur
    wait_us(39);
    write_cmd(0x01); // Effaçage de l'écran
    wait_ms(1.53);
    write_cmd(0x06); // Mode incrémental, sans décalage
}

void write_ctrl_LED(char c1, char c2){
    char commande[2] = {c1, c2};
    i2c.write(adrLED, commande, 2);
}

void color(char rouge, char vert, char bleu){
    write_ctrl_LED(0x00, 0x00); // Mode register 1
    write_ctrl_LED(0x01, 0x00); // Mode register 2
    write_ctrl_LED(0x02, bleu); // PWM0
    write_ctrl_LED(0x03, vert);  // PWM1
    write_ctrl_LED(0x04, rouge);  // PWM2
    write_ctrl_LED(0x08, 0xFF); // LEDOUT
}

void print_LCD_char(char c){
    write_data(c); 
}

void print_LCD_String(char *s){
    int i = 0;
    while(s[i] != '\0'){
        print_LCD_char(s[i]);
        i += 1;  
    }
}


